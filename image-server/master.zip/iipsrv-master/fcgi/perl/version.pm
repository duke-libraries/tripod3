package FCGI;

$VERSION = '0.67';
